#ifndef __BSP_TIMER_H
#define __BSP_TIMER_H

#include "bsp.h"

//ϵͳ��Ƶ��1ms��ʱ��ֵ����
#define FOSC   	206438400UL
#define T1MS    (65536-FOSC/12/1000)

extern u16 num;

void Timer0_Init(void);
void Timer1_Init(void);
void Timer2_Init(void);
void delay_us(u16 us);
void delay_ms(u16 ms);
void _timer_enable(uint16_t timer_number);
void _timer_disble(uint16_t timer_number);
void _tmr_set(uint16_t TID, uint16_t TSet, uint16_t timebase);
void _tmr_reset(uint16_t TID);
void MTimer_Init(void);

#endif

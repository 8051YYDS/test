#include "bsp_DI.h"

#define  DI_DELAY  10	//�˲�ʱ��10*2=20ms

//�����������ʼ��
void DI_Init(void)		
{
	P2MDOUT&=0x00;		//��������
	P2|=0xFF;			//��ʼ�ߵ�ƽ
    run.x=0;
	run.di_x=0;
}

//�������ɼ�
void DI_Update(void)	
{
	run.di_x = run.x & 0x00FF;			//����������
}

//ÿ1ms�����һ�Σ������˲����ݶ�Ϊ20ms
void DI_filter(void)                 	
{
    static signed char x_buffer[8]; 
    uint8_t temp = 0;

    //X0
    if (P20)
    {
        if (x_buffer[temp] > -DI_DELAY)
            x_buffer[temp]--;
        else
            run.x &= ~(1 << temp);
    }
    else
    {
        if (x_buffer[temp] < DI_DELAY)
            x_buffer[temp]++;
        else
            run.x |= (1 << temp);
    }
	
	temp++;
    //X1
    if (P21)
    {
        if (x_buffer[temp] > -DI_DELAY)
            x_buffer[temp]--;
        else
            run.x &= ~(1 << temp);
    }
    else
    {
        if (x_buffer[temp] < DI_DELAY)
            x_buffer[temp]++;
        else
            run.x |= (1 << temp);
    }
	
	temp++;
    //X2
    if (P22)
    {
        if (x_buffer[temp] > -DI_DELAY)
            x_buffer[temp]--;
        else
            run.x &= ~(1 << temp);
    }
    else
    {
        if (x_buffer[temp] < DI_DELAY)
            x_buffer[temp]++;
        else
            run.x |= (1 << temp);
    }
	
	temp++;
    //X3
    if (P23)
    {
        if (x_buffer[temp] > -DI_DELAY)
            x_buffer[temp]--;
        else
            run.x &= ~(1 << temp);
    }
    else
    {
        if (x_buffer[temp] < DI_DELAY)
            x_buffer[temp]++;
        else
            run.x |= (1 << temp);
    }
	
	temp++;
	//X4
    if (P24)
    {
        if (x_buffer[temp] > -DI_DELAY)
            x_buffer[temp]--;
        else
            run.x &= ~(1 << temp);
    }
    else
    {
        if (x_buffer[temp] < DI_DELAY)
            x_buffer[temp]++;
        else
            run.x |= (1 << temp);
    }
	
	temp++;
    //X5
    if (P25)
    {
        if (x_buffer[temp] > -DI_DELAY)
            x_buffer[temp]--;
        else
            run.x &= ~(1 << temp);
    }
    else
    {
        if (x_buffer[temp] < DI_DELAY)
            x_buffer[temp]++;
        else
            run.x |= (1 << temp);
    }
	
	temp++;
    //X6
    if (P26)
    {
        if (x_buffer[temp] > -DI_DELAY)
            x_buffer[temp]--;
        else
            run.x &= ~(1 << temp);
    }
    else
    {
        if (x_buffer[temp] < DI_DELAY)
            x_buffer[temp]++;
        else
            run.x |= (1 << temp);
    }
	
	temp++;
    //X7
    if (P27)
    {
        if (x_buffer[temp] > -DI_DELAY)
            x_buffer[temp]--;
        else
            run.x &= ~(1 << temp);
    }
    else
    {
        if (x_buffer[temp] < DI_DELAY)
            x_buffer[temp]++;
        else
            run.x |= (1 << temp);
    }
}

#ifndef __BSP_UART_H
#define __BSP_UART_H

#include "bsp.h"

extern u8 res;

void UART2_Init(void);

#endif

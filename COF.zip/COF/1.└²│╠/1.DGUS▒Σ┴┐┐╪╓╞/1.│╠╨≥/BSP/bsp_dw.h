#ifndef __BSP_DW_H
#define __BSP_DW_H

#include "bsp.h"

void Read_dgusii_vp(int addr,char* buf,int len);
void Write_dgusii_vp(int addr,u8* buf,int len);

#endif

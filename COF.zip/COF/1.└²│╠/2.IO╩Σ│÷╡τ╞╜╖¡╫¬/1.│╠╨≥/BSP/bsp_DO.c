#include "bsp_DO.h"

//�����ʼ��
void DO_Init(void)		
{
	P1MDOUT|=0xFF;		//�������
	P1&=0x00;			//��ʼ�͵�ƽ
    run.y=0;
	run.do_y=0;
}

//���
void DO_Output(void)	
{
	//Y0
    if(run.y & 0x01)
        P10=1;
    else
        P10=0;
	
    //Y1
    if(run.y & 0x02)
        P11=1;
    else
        P11=0;
	
	//Y2
    if(run.y & 0x04)
        P12=1;
    else
        P12=0;
	
    //Y3
    if(run.y & 0x08)
        P13=1;
    else
        P13=0;
	
	//Y4
    if(run.y & 0x10)
        P14=1;
    else
        P14=0;
	
    //Y5
    if(run.y & 0x20)
        P15=1;
    else
        P15=0;
	
	//Y6
    if(run.y & 0x40)
        P16=1;
    else
        P16=0;
	
    //Y7
    if(run.y & 0x80)
        P17=1;
    else
        P17=0;
}
#ifndef __BSP_DI_H
#define __BSP_DI_H

#include "bsp.h"
#include "params.h"

sbit P20=P2^0;
sbit P21=P2^1;
sbit P22=P2^2;
sbit P23=P2^3;
sbit P24=P2^4;
sbit P25=P2^5;
sbit P26=P2^6;
sbit P27=P2^7;

void DI_Init(void);
void DI_filter(void);

#endif

#ifndef __BSP_LOGIC_H
#define __BSP_LOGIC_H

#include "bsp.h"

void _rstbit(uint16_t *p, uint8_t bitnum);
void _setbit(uint16_t *p, uint8_t bitnum);

#endif

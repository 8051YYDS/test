#include "bsp_logic.h"

void _rstbit(uint16_t *p, uint8_t bitnum)		//��λ��Ӧλ
{
    *p &= ~(1u << bitnum);
}

void _setbit(uint16_t *p, uint8_t bitnum)		//��λ��Ӧλ
{
    *p |= 1u << bitnum;
}

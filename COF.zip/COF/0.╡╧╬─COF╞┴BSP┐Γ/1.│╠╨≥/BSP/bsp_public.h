#ifndef __BSP_PUBLIC_H
#define __BSP_PUBLIC_H

#include "t5los8051.h"

//�����ض���
typedef unsigned char   u8;
typedef unsigned short  u16;
typedef unsigned long   u32;
typedef signed char     s8;
typedef signed short    s16;
typedef signed long     s32;

typedef unsigned char        	uint8_t;
typedef unsigned short int   	uint16_t;
typedef unsigned long       	uint32_t;
typedef char                 	int8_t;
typedef int                  	int16_t;
typedef signed long        		int32_t;

#endif

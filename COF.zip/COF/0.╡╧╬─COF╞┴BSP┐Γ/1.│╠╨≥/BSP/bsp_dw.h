#ifndef __BSP_DW_H
#define __BSP_DW_H

#include "bsp.h"

#define SCREEN_ID		0x14		//��ǰ��ʾ����ID
#define TOUCH_CHANGE	0x0F00		//�����ı�ָʾ��ַ

void Read_dgusii_vp(u16 addr,char* buf,int len);
void Write_dgusii_vp(u16 addr,u8* buf,int len);
void Touch_Check(void);
void Touch_Process(void);
void Screen_Change(u16 ID);
void Screen_Init(u16 ID);
void Timing_Send_Data(u16 ID);

#endif

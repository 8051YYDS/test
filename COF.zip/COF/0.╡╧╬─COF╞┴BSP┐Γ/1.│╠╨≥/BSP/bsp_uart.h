#ifndef __BSP_UART_H
#define __BSP_UART_H

#include "bsp.h"

void UART2_Init(void);

#endif

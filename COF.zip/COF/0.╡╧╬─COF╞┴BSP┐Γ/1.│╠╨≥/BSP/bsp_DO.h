#ifndef __BSP_DO_H
#define __BSP_DO_H

#include "bsp.h"
#include "params.h"

sbit P10=P1^0;
sbit P11=P1^1;
sbit P12=P1^2;
sbit P13=P1^3;
sbit P14=P1^4;
sbit P15=P1^5;
sbit P16=P1^6;
sbit P17=P1^7;

void DO_Init(void);
void DO_Output(void);

#endif

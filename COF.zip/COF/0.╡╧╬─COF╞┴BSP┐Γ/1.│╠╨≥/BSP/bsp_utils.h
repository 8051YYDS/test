#ifndef __BSP_UTILS_H
#define __BSP_UTILS_H

#include "bsp_public.h"

//8λ�����嶨��
typedef union 
{
    uint8_t RegByte;
    struct
    {
        uint8_t b0 :1;
        uint8_t b1 :1;
        uint8_t b2 :1;
        uint8_t b3 :1;
        uint8_t b4 :1;
        uint8_t b5 :1;
        uint8_t b6 :1;
        uint8_t b7 :1;
    } RegBits;
} REG8_T;

//16λ�����嶨��
typedef union
{
    uint16_t RegWord;
    struct
    {
        uint8_t LoByte;
        uint8_t HiByte;
    } RegBytes;
    struct
    {
        uint16_t b0 :1;
        uint16_t b1 :1;
        uint16_t b2 :1;
        uint16_t b3 :1;
        uint16_t b4 :1;
        uint16_t b5 :1;
        uint16_t b6 :1;
        uint16_t b7 :1;
        uint16_t b8 :1;
        uint16_t b9 :1;
        uint16_t b10 :1;
        uint16_t b11 :1;
        uint16_t b12 :1;
        uint16_t b13 :1;
        uint16_t b14 :1;
        uint16_t b15 :1;
    } RegBits;
} REG16_T;

//32λ�����嶨��
typedef union
{
    uint32_t RegWord;
    struct
    {
        REG16_T LoByte;
        REG16_T HiByte;
    } RegBytes;
} REG32_T;

uint16_t CRC16(uint8_t *pData, uint16_t iLength);
void my_memcpy(uint8_t *dest, uint8_t *src, uint16_t n);

#endif

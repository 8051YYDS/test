#ifndef __BSP_H
#define __BSP_H

#include "bsp_public.h"

#include "bsp_dw.h"
#include "bsp_DO.h"
#include "bsp_DI.h"
#include "bsp_timer.h"
#include "bsp_logic.h"
#include "bsp_uart.h"
#include "bsp_AI.h"
#include "bsp_utils.h"
#include "bsp_nor_flash.h"

#ifndef TRUE
#define TRUE  1
#endif

#ifndef FALSE
#define FALSE 0
#endif

void BSP_Init(void);

#endif
